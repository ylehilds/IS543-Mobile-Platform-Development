//
//  Preferences.swift
//  Day8 Calculator
//
//  Created by Stephen Liddle on 10/5/23.
//

import Foundation

struct Preferences {
    // This is the "stored property" version:
    var soundIsEnabled = UserDefaults.standard.bool(forKey: Key.enableSound) {
        // This is a "property observer"
        didSet {
            UserDefaults.standard.set(soundIsEnabled, forKey: Key.enableSound)
        }
    }

// This is the "computed property" version:
//
//    private var _enableSound = UserDefaults.standard.bool(forKey: Key.enableSound)
//
//    var enableSound: Bool {
//        get {
//            _enableSound
//        }
//        set {
//            _enableSound = newValue
//            UserDefaults.standard.set(newValue, forKey: Key.enableSound)
//        }
//    }

    private struct Key {
        static let enableSound = "EnableSound"
    }
}
